#!/usr/bin/env bash
set -e
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or with sudo: sudo ./uninstall.sh"
    exit 1
fi
if command -v systemctl >/dev/null 2>&1; then
    systemctl stop trackercontrol.service >/dev/null 2>&1 || true
    systemctl disable trackercontrol.service >/dev/null 2>&1 || true
fi
rm -f /usr/local/bin/trackercontrol
rm -f /usr/local/share/applications/trackercontrol.desktop
rm -f /usr/local/share/icons/hicolor/scalable/apps/trackercontrol.svg
rm -f /etc/systemd/system/trackercontrol.service
echo "✓ TrackerControl successfully uninstalled."

#!/usr/bin/env bash
set -e
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root or with sudo: sudo ./install.sh"
    exit 1
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install -m 755 "${SCRIPT_DIR}/trackercontrol" /usr/local/bin/trackercontrol
install -d -m 755 /usr/local/share/applications
install -m 644 "${SCRIPT_DIR}/trackercontrol.desktop" /usr/local/share/applications/
install -d -m 755 /usr/local/share/icons/hicolor/scalable/apps
install -m 644 "${SCRIPT_DIR}/trackercontrol.svg" /usr/local/share/icons/hicolor/scalable/apps/
if [ -d "/etc/systemd/system" ]; then
    install -m 644 "${SCRIPT_DIR}/trackercontrol.service" /etc/systemd/system/
    systemctl daemon-reload || true
fi
echo "✓ TrackerControl successfully installed to /usr/local/bin/trackercontrol!"
echo "  Launch anytime by running: sudo trackercontrol"

#!/usr/bin/env bash
# ==============================================================================
# TrackerControl PC — macOS Installer
# Installs TrackerControl.app into /Applications/ and configures permissions.
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="/Applications/TrackerControl.app"

echo "========================================================================"
echo "  📦 Installing TrackerControl PC to /Applications/..."
echo "========================================================================"

if [ ! -d "${SCRIPT_DIR}/TrackerControl.app" ]; then
    echo "[-] TrackerControl.app not found in ${SCRIPT_DIR}"
    exit 1
fi

rm -rf "${TARGET}"
cp -R "${SCRIPT_DIR}/TrackerControl.app" "/Applications/"
chmod +x "${TARGET}/Contents/MacOS/TrackerControl"

# Also symlink to /usr/local/bin if directory exists
if [ -d "/usr/local/bin" ] && [ -w "/usr/local/bin" ]; then
    ln -sf "${TARGET}/Contents/MacOS/TrackerControl" "/usr/local/bin/trackercontrol" || true
    echo "[+] Symlinked command 'trackercontrol' to /usr/local/bin/trackercontrol"
fi

echo "[✓] TrackerControl PC installed successfully!"
echo "    Launch from Launchpad, Finder (/Applications), or run: open /Applications/TrackerControl.app"

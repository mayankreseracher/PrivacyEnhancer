#!/usr/bin/env bash
# ==============================================================================
# TrackerControl PC — macOS Uninstaller
# ==============================================================================
set -e

echo "Uninstalling TrackerControl PC..."
rm -rf "/Applications/TrackerControl.app"
rm -f "/usr/local/bin/trackercontrol"
echo "[✓] TrackerControl PC uninstalled cleanly."
